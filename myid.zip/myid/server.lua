local discordWebhookUrl = "YOUR_DISCORD_WEBHOOK_URL" ---------- add webhook

AddEventHandler('playerConnecting', function(playerName, setKickReason)
    local identifiers = GetPlayerIdentifiers(source)
    for i, identifier in ipairs(identifiers) do
        print('Player: ' .. playerName .. ', Identifier #' .. i .. ': ' .. identifier)
    end
    local discordMessage = {
        content = "Player Connecting",  ---------- add name
        username = "YourBotName",  ---------- add Bot name
        avatar_url = "YourBotAvatarUrl",  ---------- add Bot pic webhook
        embeds = {
            {
                title = "Player Connecting", ---------- add name
                description = "Player: " .. playerName,
                fields = {
                    { name = "Identifiers", value = table.concat(identifiers, '\n') },
                },
                color = 16711680 -- You can change this to any color you want
            }
        }
    }

    local jsonMessage = json.encode(discordMessage)

    PerformHttpRequest(discordWebhookUrl, function(err, text, headers)
        if err == 200 then
            print("Successfully sent player connection info to Discord!")
        else
            print("Error sending player connection info to Discord:", err)
        end
    end, 'POST', jsonMessage, { ['Content-Type'] = 'application/json' })
end)