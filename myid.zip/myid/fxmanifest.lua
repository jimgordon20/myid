fx_version 'cerulean'
game 'gta5'

author 'jim gordon the on and only  <https://github.com/jimgordon20>'
description 'Send players IDs to discord webhook on join.'
version '1.0.0'
url 'https://github.com/jimgordon20'

server_script 'server.lua'
